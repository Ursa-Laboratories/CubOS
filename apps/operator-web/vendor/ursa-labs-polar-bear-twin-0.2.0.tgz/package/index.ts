import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { RGBELoader } from 'three/examples/jsm/loaders/RGBELoader.js';

export { createInstrumentHead, instrumentHeadLabel, type InstrumentDescriptor } from './instrumentHeads';

export type Pose = { x: number; y: number; z: number };
export type View = 'iso' | 'tool' | 'top' | 'front' | 'right';
// Display registration for the offline example, in deck-frame mm.
export const CAD_REST: Pose = { x: 195, y: 195, z: 35 };

function findPart(root: THREE.Object3D, name: string) {
  const part = root.getObjectByName(name);
  if (!part) throw new Error(`Missing assembly part: ${name}`);
  return part;
}

function bindAssembly(root: THREE.Group) {
  const bridge = findPart(root, 'YBridge');
  const saddle = findPart(bridge, 'XSaddle');
  const carriage = findPart(saddle, 'ZCarriage');
  const tool = findPart(carriage, 'SartoriusTool');
  const origins = [bridge, saddle, carriage].map(node => node.position.clone());
  return {
    root, bridge, saddle, carriage, tool,
    move(pose: Pose | null) {
      const { x, y, z } = pose ?? CAD_REST;
      // glTF meters, Y up. The bridge moves toward -Z as CubOS Y increases.
      bridge.position.z = origins[0].z - (y - CAD_REST.y) / 1000;
      saddle.position.x = origins[1].x + (x - CAD_REST.x) / 1000;
      carriage.position.y = origins[2].y + (z - CAD_REST.z) / 1000;
      root.updateMatrixWorld(true);
    },
  };
}

export type Assembly = ReturnType<typeof bindAssembly>;

function disposeModel(root: THREE.Object3D) {
  const materials = new Set<THREE.Material>();
  const geometries = new Set<THREE.BufferGeometry>();
  root.traverse(node => {
    if (node instanceof THREE.Mesh) {
      geometries.add(node.geometry);
      for (const material of [node.material].flat()) materials.add(material);
    }
  });
  for (const geometry of geometries) geometry.dispose();
  for (const material of materials) material.dispose();
}

function frameAssembly(camera: THREE.PerspectiveCamera, orbit: OrbitControls, object: THREE.Object3D, view: View) {
  object.updateWorldMatrix(true, true);
  const bounds = new THREE.Box3();
  const box = new THREE.Box3();
  object.traverseVisible(mesh => {
    if (!(mesh instanceof THREE.Mesh)) return;
    if (!mesh.geometry.boundingBox) mesh.geometry.computeBoundingBox();
    box.copy(mesh.geometry.boundingBox!).applyMatrix4(mesh.matrixWorld);
    bounds.union(box);
  });
  if (bounds.isEmpty()) return;
  const target = bounds.getCenter(new THREE.Vector3());
  const directions: Record<View, [number, number, number]> = {
    iso: [-0.64, 0.49, 1], tool: [-0.72, 0.26, 1], front: [0, 0, 1], right: [1, 0, 0], top: [0, 1, 0],
  };
  const direction = new THREE.Vector3(...directions[view]).normalize();
  camera.up.set(0, view === 'top' ? 0 : 1, view === 'top' ? -1 : 0);
  const right = new THREE.Vector3().crossVectors(camera.up, direction).normalize();
  const up = new THREE.Vector3().crossVectors(direction, right).normalize();
  const tanY = Math.tan(THREE.MathUtils.degToRad(camera.fov / 2));
  const tanX = tanY * camera.aspect;
  const corners: THREE.Vector3[] = [];
  let distance = 0.05;
  object.traverseVisible(mesh => {
    if (!(mesh instanceof THREE.Mesh)) return;
    if (!mesh.geometry.boundingBox) mesh.geometry.computeBoundingBox();
    const { min, max } = mesh.geometry.boundingBox!;
    for (const x of [min.x, max.x]) for (const y of [min.y, max.y]) for (const z of [min.z, max.z]) {
      const point = new THREE.Vector3(x, y, z).applyMatrix4(mesh.matrixWorld);
      corners.push(point);
      const corner = point.clone().sub(target);
      const extent = Math.max(Math.abs(corner.dot(right)) / tanX, Math.abs(corner.dot(up)) / tanY);
      distance = Math.max(distance, corner.dot(direction) + extent * 1.14);
    }
  });
  // Centre the perspective silhouette too: the tall backboard sits at the
  // rear, so the world bounding-box centre leaves empty space above the rig.
  const relative = new THREE.Vector3();
  for (let pass = 0; pass < 4; pass++) {
    let left = Infinity, rightEdge = -Infinity, bottom = Infinity, top = -Infinity;
    for (const point of corners) {
      relative.copy(point).sub(target);
      const depth = Math.max(0.005, distance - relative.dot(direction));
      const u = relative.dot(right) / (depth * tanX);
      const v = relative.dot(up) / (depth * tanY);
      left = Math.min(left, u); rightEdge = Math.max(rightEdge, u);
      bottom = Math.min(bottom, v); top = Math.max(top, v);
    }
    target.addScaledVector(right, (left + rightEdge) * distance * tanX / 2);
    target.addScaledVector(up, (bottom + top) * distance * tanY / 2);
    distance *= Math.max(rightEdge - left, top - bottom) / 1.78;
  }
  camera.position.copy(target).addScaledVector(direction, distance);
  orbit.target.copy(target);
  orbit.update();
}

function createStudio(mount: HTMLDivElement) {
  const scene = new THREE.Scene();
  const hardware = new THREE.Group();
  scene.add(hardware);
  const camera = new THREE.PerspectiveCamera(31, 1, 0.004, 15);
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.03;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.setClearColor(0, 0);
  mount.appendChild(renderer.domElement);
  const orbit = new OrbitControls(camera, renderer.domElement);
  orbit.minDistance = 0.06;
  orbit.maxDistance = 4;
  orbit.maxPolarAngle = Math.PI * 0.515;
  orbit.zoomToCursor = true;
  scene.environmentIntensity = 0.95;
  scene.environmentRotation.y = 0.85;

  const key = new THREE.DirectionalLight(0xfff6e7, 1.7);
  key.position.set(-0.55, 1.35, 0.72);
  key.target.position.set(0.2, 0, -0.3);
  key.castShadow = true;
  key.shadow.mapSize.set(2048, 2048);
  Object.assign(key.shadow.camera, { left: -0.57, right: 0.57, top: 0.57, bottom: -0.57, near: 0.3, far: 3 });
  key.shadow.camera.updateProjectionMatrix();
  key.shadow.normalBias = 0.00025;
  key.shadow.bias = -0.00008;
  const fill = new THREE.DirectionalLight(0xd9e8ff, 0.42);
  fill.position.set(0.8, 0.75, -0.65);
  scene.add(key, key.target, fill);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(15, 15), new THREE.ShadowMaterial({ opacity: 0.3 }));
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  scene.add(floor);
  let frame = 0;
  let disposed = false;
  function redraw() {
    if (disposed || frame) return;
    frame = requestAnimationFrame(() => { frame = 0; renderer.render(scene, camera); });
  }
  orbit.addEventListener('change', redraw);
  return {
    scene, camera, orbit, renderer, floor, hardware, redraw,
    dispose() {
      disposed = true;
      cancelAnimationFrame(frame);
      orbit.dispose();
      // The host owns any deck overlays it added to the scene.
      disposeModel(hardware);
      disposeModel(floor);
      key.shadow.dispose();
      scene.environment?.dispose();
      renderer.dispose();
      renderer.forceContextLoss();
      renderer.domElement.remove();
    },
  };
}

/** Create one orbitable, render-on-demand stage. Assets are served by the host app. */
export function mountPolarStudio(element: HTMLDivElement, modelUrl: string, environmentUrl: string,
  options: { showReferenceTool?: boolean } = {},
) {
  const stage = createStudio(element);
  const controller = new AbortController();
  let rig: Assembly | undefined;
  let view: View = 'iso';
  let position: Pose | null = null;
  let selection: THREE.Object3D | null = null;
  function frame() {
    if (!rig) return;
    if (selection && !stage.scene.getObjectById(selection.id)) { selection = null; view = 'iso'; }
    const object = selection ?? (view === 'tool' && rig.tool.visible ? rig.tool : rig.root);
    frameAssembly(stage.camera, stage.orbit, object, view);
    stage.redraw();
  }
  function fit(next: View = 'iso') { view = next; selection = null; frame(); }
  function fitObject(object: THREE.Object3D) { view = 'tool'; selection = object; frame(); }
  function resize() {
    const w = Math.max(element.clientWidth, 1), h = Math.max(element.clientHeight, 1);
    stage.renderer.setSize(w, h);
    stage.camera.aspect = w / h;
    stage.camera.updateProjectionMatrix();
    frame();
  }
  resize();
  const observer = new ResizeObserver(resize);
  observer.observe(element);
  async function loadLights() {
    try {
      const texture = await new RGBELoader().loadAsync(environmentUrl);
      if (controller.signal.aborted) { texture.dispose(); return; }
      texture.mapping = THREE.EquirectangularReflectionMapping;
      stage.scene.environment = texture;
    } catch {
      if (!controller.signal.aborted) stage.scene.add(new THREE.HemisphereLight(0xffffff, 0xaab1b8, 1.4));
    }
  }
  const lightsReady = loadLights();
  async function loadAssembly() {
    const response = await fetch(modelUrl, { signal: controller.signal });
    if (!response.ok) throw new Error(`CAD asset returned HTTP ${response.status}`);
    const gltf = await new GLTFLoader().parseAsync(await response.arrayBuffer(), '');
    if (controller.signal.aborted) { disposeModel(gltf.scene); throw new DOMException('Disposed', 'AbortError'); }
    stage.hardware.add(gltf.scene);
    rig = bindAssembly(gltf.scene);
    rig.tool.visible = options.showReferenceTool ?? true;
    rig.root.traverse(node => { if (node instanceof THREE.Mesh) node.castShadow = node.receiveShadow = true; });
    stage.floor.position.y = new THREE.Box3().setFromObject(rig.root).min.y - 0.0002;
    rig.move(position);
    frame();
    await lightsReady;
    if (!controller.signal.aborted) stage.redraw();
    return rig;
  }
  return {
    scene: stage.scene, redraw: stage.redraw, ready: loadAssembly(), fit, fitObject,
    move(pose: Pose | null) { position = pose; rig?.move(pose); stage.redraw(); },
    dispose() { controller.abort(); observer.disconnect(); stage.dispose(); },
  };
}
export type PolarStudio = ReturnType<typeof mountPolarStudio>;
