# Polar Bear studio model

A local, Y-up, metre-scale glTF assembly and an orbitable Three.js stage for CubOS Operator and the offline trace viewer. The CAD rest pose corresponds to an illustrative replay position of (195, 195, 35) mm. Call `move` with a registered pose in millimetres, `fit` for preset views, and `dispose` on unmount. `scene` accepts host-specific deck overlays.

The fixed table and fixture, Y bridge, X saddle and Z carriage come from [Polar Bear CAD](https://github.com/BU-KABlab/polar-bear/tree/0477df026d37184a314968450f4db316d5ba2f06/hardware/cad). The mounted tool combines [both Cubware front and back Rev. 0 STLs](https://github.com/Ursa-Laboratories/Cubware/tree/a05b8d36c0a415c735abe691a2f59a4e2990b797/cub/Instrument%20Mounts/Cub%20Sartorius%20Pipette%20Mount) and the separately supplied Picus 2 5 mL STEP. Tool registration and finishes are approximate. The shell tab and backboard fasteners have different axes. See `examples/polar-bear/cad` in CubOS-Digital-Twin for the source STEP and build scripts. The studio HDR environment is derived from Blender's bundled `studio.exr`, CC0 by Greg Zaal / Poly Haven.

## Configured instrument heads

`createInstrumentHead(config, key)` resolves a mesh from the CubOS instrument type, vendor and pipette model. It returns an independently disposable group with its origin at the active end and +Y toward the carriage. Operator attaches one group per configured instrument, with X/Y offsets and depth in millimetres. `mountPolarStudio(..., { showReferenceTool: false })` keeps the original assembly's fixed Picus reference out of this configuration-driven view. `fitObject(group)` frames the selected heads.

The catalog includes ASMI, film thickness and UV–Vis probes, an OmniCure light guide, Opentrons and Sartorius pipette families, electrode assemblies, cameras, capper and LED ring. A passive tool whose configured key contains the word `raman` gets the document's Raman probe visual. Other unrecognized tools use a generic reference. See `examples/instrument-heads` for source evidence, rebuild commands and estimated dimensions.
