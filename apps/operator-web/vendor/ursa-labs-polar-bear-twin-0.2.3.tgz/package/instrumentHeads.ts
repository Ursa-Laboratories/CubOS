import { Group, Mesh } from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import asmi from './heads/asmi-vernier.glb?url';
import filmetrics from './heads/filmetrics-kla.glb?url';
import uvvis from './heads/uvvis-ccs-thorlabs.glb?url';
import curing from './heads/uv-curing-excelitas.glb?url';
import raman from './heads/raman-probe.glb?url';
import opentronsSingle from './heads/pipette-opentrons-single.glb?url';
import opentronsMulti from './heads/pipette-opentrons-multi.glb?url';
import sartoriusSingle from './heads/pipette-sartorius-single.glb?url';
import sartorius300 from './heads/pipette-sartorius-300.glb?url';
import sartoriusMulti from './heads/pipette-sartorius-multi.glb?url';
import sartorius5ml from './heads/pipette-sartorius-5ml.glb?url';
import admiral from './heads/potentiostat-admiral.glb?url';
import emstat from './heads/potentiostat-emstat.glb?url';
import flir from './heads/camera-flir.glb?url';
import pi from './heads/camera-raspberry-pi.glb?url';
import lighting from './heads/lighting-ring.glb?url';
import capper from './heads/capper.glb?url';
import passive from './heads/mounted-tool.glb?url';

export interface InstrumentDescriptor {
  type: string;
  vendor?: string;
  pipette_model?: unknown;
}

type Head = { label: string; url: string | null };
const passiveHead = { label: 'Passive tool reference', url: passive };
const capperHead = { label: 'Vial capper', url: capper };
const ringHead = { label: 'LED ring', url: lighting };
const heads: Record<string, Record<string, Head>> = {
  asmi: { vernier: { label: 'Vernier ASMI', url: asmi } },
  filmetrics: { kla: { label: 'Filmetrics F20 probe', url: filmetrics } },
  uvvis_ccs: { thorlabs: { label: 'Thorlabs CCS probe', url: uvvis } },
  uv_curing: { excelitas: { label: 'OmniCure light guide', url: curing } },
  potentiostat: {
    admiral: { label: 'Admiral electrode reference', url: admiral },
    emstat: { label: 'EmStat electrode reference', url: emstat },
  },
  camera: {
    flir: { label: 'FLIR camera', url: flir }, raspberry_pi: { label: 'Raspberry Pi camera', url: pi },
    opencv: { label: 'OpenCV camera · position only', url: null },
    mount_only: { label: 'Camera · position only', url: null },
  },
  capper: { pawduino: capperHead, nano_text: capperHead, mock: { label: 'Simulated capper', url: capper } },
  lighting: { pawduino: ringHead, nano_text: ringHead },
};

function modelFor(config: InstrumentDescriptor, key: string): Head {
  const model = typeof config.pipette_model === 'string' ? config.pipette_model : '';
  if (config.type === 'pipette' && config.vendor === 'sartorius') {
    const selected = model || 'picus2_1ch_1000';
    const match = /^picus2_(1|8)ch_(\d+)$/.exec(selected);
    if (selected === 'picus2_1ch_300') return { label: 'Picus 2 · 1 ch · 300 µL', url: sartorius300 };
    if (selected === 'picus2_1ch_5000') return { label: 'Picus 2 · 5 mL', url: sartorius5ml };
    if (!match) return { label: 'Picus 2 reference', url: sartoriusSingle };
    return { label: `Picus 2 · ${match[1]} ch · ${match[2]} µL`, url: match[1] === '8' ? sartoriusMulti : sartoriusSingle };
  }
  if (config.type === 'pipette' && config.vendor === 'opentrons') {
    const match = /^p(\d+)_(single|multi)_gen2$/.exec(model || 'p300_single_gen2');
    if (!match) return { label: 'Opentrons pipette reference', url: opentronsSingle };
    return { label: `Opentrons P${match[1]} · ${match[2] === 'multi' ? '8 ch' : '1 ch'}`, url: match[2] === 'multi' ? opentronsMulti : opentronsSingle };
  }
  if (config.type === 'mounted_tool' && config.vendor === 'mount_only' && /(^|[^a-z])raman([^a-z]|$)/i.test(key)) {
    return { label: 'Raman probe · passive mount', url: raman };
  }
  return heads[config.type]?.[config.vendor ?? ''] ?? passiveHead;
}

export function instrumentHeadLabel(config: InstrumentDescriptor, key = '') {
  return modelFor(config, key).label;
}

/** Meshes use metres. Each group has an independent set of disposable GPU resources. */
export async function createInstrumentHead(config: InstrumentDescriptor, key = ''): Promise<Group | null> {
  const { label, url } = modelFor(config, key);
  if (url === null) return null;
  const { scene } = await new GLTFLoader().loadAsync(url);
  scene.name = label;
  scene.traverse(object => {
    if (object instanceof Mesh) object.castShadow = object.receiveShadow = true;
  });
  return scene;
}
